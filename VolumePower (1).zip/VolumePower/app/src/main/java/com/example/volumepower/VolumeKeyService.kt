package com.example.volumepower

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumeKeyService : AccessibilityService() {

    companion object {
        var instance: VolumeKeyService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pm: PowerManager
    private lateinit var audio: AudioManager

    private var longPressFired = false
    private var tapCount = 0

    private val longPress = Runnable {
        longPressFired = true
        tapCount = 0
        handler.removeCallbacks(tapRunnable)
        if (pm.isInteractive) {
            performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
        } else {
            ScreenHelper.wake(this)
            handler.postDelayed({ performGlobalAction(GLOBAL_ACTION_POWER_DIALOG) }, 700)
        }
        EventLog.add("ACC: চেপে ধরা → পাওয়ার মেনু")
    }

    private val tapRunnable = Runnable {
        if (tapCount == 1) {
            audio.adjustSuggestedStreamVolume(
                AudioManager.ADJUST_LOWER,
                AudioManager.USE_DEFAULT_STREAM_TYPE,
                AudioManager.FLAG_SHOW_UI
            )
        } else if (tapCount >= 2) {
            EventLog.add("ACC: ডাবল চাপ → ফ্ল্যাশ")
            TorchHelper.toggle(this)
        }
        tapCount = 0
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        EventLog.add("Accessibility সার্ভিস সংযুক্ত")
        try {
            startForegroundService(Intent(this, KeyService::class.java))
        } catch (_: Exception) {
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        val screenOn = pm.isInteractive
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            EventLog.add(
                "ACC বাটন " + (if (code == KeyEvent.KEYCODE_VOLUME_UP) "UP" else "DOWN") +
                    " স্ক্রীন-অন=$screenOn"
            )
        }

        // স্ক্রীন অন + গান/ভিডিও/কল চললে স্বাভাবিক ভলিউম
        if (screenOn && (audio.isMusicActive || audio.mode != AudioManager.MODE_NORMAL)) return false

        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event.action == KeyEvent.ACTION_UP) {
                if (screenOn) {
                    performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                } else {
                    ScreenHelper.wake(this)
                    EventLog.add("ACC: স্ক্রীন অন করা হলো")
                }
            }
            return true
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                longPressFired = false
                handler.postDelayed(longPress, 600)
            }
        } else if (event.action == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(longPress)
            if (!longPressFired) {
                tapCount++
                handler.removeCallbacks(tapRunnable)
                handler.postDelayed(tapRunnable, 300)
            }
        }
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
