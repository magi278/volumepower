package com.example.volumepower

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.VolumeProvider
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock

/**
 * স্ক্রীন অফ অবস্থায় ভলিউম বাটন ধরার জন্য: একটি মিডিয়া সেশন সক্রিয় করা হয়,
 * ফলে সিস্টেম ভলিউম বাটনের ইভেন্ট এই সেশনকে পাঠায়।
 */
class KeyService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pm: PowerManager
    private lateinit var audio: AudioManager
    private lateinit var session: MediaSession

    @Volatile private var silenceRunning = false

    private var lastUp = 0L
    private var lastDown = 0L
    private var taps = 0
    private var holdFired = false

    private val resolveTaps = Runnable {
        if (taps >= 2) TorchHelper.toggle(this)
        taps = 0
    }

    private val provider = object : VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
        override fun onAdjustVolume(direction: Int) {
            handler.post { onVolume(direction) }
        }
    }

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> activate()
                Intent.ACTION_SCREEN_ON -> deactivate()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager

        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("vp", "Volume Power", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, "vp")
            .setContentTitle("Volume Power চালু আছে")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        } else {
            startForeground(1, n)
        }

        session = MediaSession(this, "VolumePower")
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        registerReceiver(screenReceiver, f)
        if (!pm.isInteractive) activate()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    private fun activate() {
        session.setPlaybackToRemote(provider)
        session.setPlaybackState(
            PlaybackState.Builder()
                .setActions(PlaybackState.ACTION_PLAY_PAUSE)
                .setState(PlaybackState.STATE_PLAYING, 0, 1f)
                .build()
        )
        session.isActive = true
        startSilence()
    }

    private fun deactivate() {
        session.isActive = false
        stopSilence()
    }

    private fun startSilence() {
        if (silenceRunning) return
        silenceRunning = true
        Thread {
            val minBuf = AudioTrack.getMinBufferSize(
                8000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(8000)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .build()
                )
                .setBufferSizeInBytes(minBuf)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            track.play()
            val buf = ShortArray(minBuf)
            while (silenceRunning) {
                track.write(buf, 0, buf.size)
            }
            track.stop()
            track.release()
        }.start()
    }

    private fun stopSilence() {
        silenceRunning = false
    }

    private fun onVolume(direction: Int) {
        if (direction == 0) return

        // স্ক্রীন অন থাকলে স্বাভাবিক ভলিউম
        if (pm.isInteractive) {
            audio.adjustStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI
            )
            return
        }

        val now = SystemClock.uptimeMillis()

        if (direction > 0) {
            // ভলিউম আপ → স্ক্রীন অন
            if (now - lastUp > 600) {
                lastUp = now
                ScreenHelper.wake(this)
            }
            return
        }

        // ভলিউম ডাউন
        val gap = now - lastDown
        lastDown = now
        if (gap >= 700) holdFired = false

        if (gap < 130) {
            // দ্রুত পরপর ইভেন্ট = বাটন চেপে ধরা আছে
            if (!holdFired) {
                holdFired = true
                handler.removeCallbacks(resolveTaps)
                taps = 0
                ScreenHelper.wake(this)
                handler.postDelayed({
                    VolumeKeyService.instance?.performGlobalAction(
                        android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
                    )
                }, 600)
            }
            return
        }

        taps++
        handler.removeCallbacks(resolveTaps)
        handler.postDelayed(resolveTaps, 350)
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(screenReceiver)
        } catch (_: Exception) {
        }
        stopSilence()
        session.release()
        super.onDestroy()
    }
}
