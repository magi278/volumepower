package com.example.volumepower

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumeKeyService : AccessibilityService() {

    companion object {
        var instance: VolumeKeyService? = null
    }

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pm: PowerManager
    private lateinit var audio: AudioManager

    private var longPressFired = false
    private var tapCount = 0

    private val longPress = Runnable {
        longPressFired = true
        performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    }

    private val tapRunnable = Runnable {
        if (tapCount == 1) {
            audio.adjustSuggestedStreamVolume(
                AudioManager.ADJUST_LOWER,
                AudioManager.USE_DEFAULT_STREAM_TYPE,
                AudioManager.FLAG_SHOW_UI
            )
        } else if (tapCount >= 2) {
            TorchHelper.toggle(this)
        }
        tapCount = 0
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        try {
            startForegroundService(Intent(this, KeyService::class.java))
        } catch (_: Exception) {
        }
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        val screenOn = pm.isInteractive
        if (!screenOn) return false // স্ক্রীন অফ অবস্থা KeyService সামলায়
        if (audio.isMusicActive || audio.mode != AudioManager.MODE_NORMAL) return false

        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event.action == KeyEvent.ACTION_UP) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
            return true
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                longPressFired = false
                handler.postDelayed(longPress, 600)
            }
        } else if (event.action == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(longPress)
            if (!longPressFired) {
                tapCount++
                handler.removeCallbacks(tapRunnable)
                handler.postDelayed(tapRunnable, 300)
            }
        }
        return true
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }
}
