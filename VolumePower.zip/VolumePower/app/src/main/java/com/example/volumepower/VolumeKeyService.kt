package com.example.volumepower

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VolumeKeyService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var pm: PowerManager
    private lateinit var audio: AudioManager
    private lateinit var camera: CameraManager

    private var torchOn = false
    private var torchId: String? = null

    private var longPressFired = false
    private var tapCount = 0

    private val longPress = Runnable {
        longPressFired = true
        performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)
    }

    private val tapRunnable = Runnable {
        if (tapCount == 1) {
            audio.adjustSuggestedStreamVolume(
                AudioManager.ADJUST_LOWER,
                AudioManager.USE_DEFAULT_STREAM_TYPE,
                AudioManager.FLAG_SHOW_UI
            )
        } else if (tapCount >= 2) {
            toggleTorch()
        }
        tapCount = 0
    }

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchId) torchOn = enabled
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        camera = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        torchId = camera.cameraIdList.firstOrNull {
            val c = camera.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        camera.registerTorchCallback(torchCallback, handler)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        if (code != KeyEvent.KEYCODE_VOLUME_UP && code != KeyEvent.KEYCODE_VOLUME_DOWN) return false

        val screenOn = pm.isInteractive
        // স্ক্রীন অন + গান/ভিডিও/কল চলছে → স্বাভাবিক ভলিউম কাজ করবে
        if (screenOn && (audio.isMusicActive || audio.mode != AudioManager.MODE_NORMAL)) return false

        if (code == KeyEvent.KEYCODE_VOLUME_UP) {
            if (event.action == KeyEvent.ACTION_UP) {
                if (screenOn) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN) else wakeScreen()
            }
            return true
        }

        // ভলিউম ডাউন
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (event.repeatCount == 0) {
                longPressFired = false
                handler.postDelayed(longPress, 600)
            }
        } else if (event.action == KeyEvent.ACTION_UP) {
            handler.removeCallbacks(longPress)
            if (!longPressFired) {
                tapCount++
                handler.removeCallbacks(tapRunnable)
                handler.postDelayed(tapRunnable, 300)
            }
        }
        return true
    }

    @Suppress("DEPRECATION")
    private fun wakeScreen() {
        val wl = pm.newWakeLock(
            PowerManager.FULL_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE,
            "VolumePower:wake"
        )
        wl.acquire(3000)
    }

    private fun toggleTorch() {
        val id = torchId ?: return
        try {
            camera.setTorchMode(id, !torchOn)
        } catch (_: Exception) {
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onDestroy() {
        camera.unregisterTorchCallback(torchCallback)
        super.onDestroy()
    }
}
