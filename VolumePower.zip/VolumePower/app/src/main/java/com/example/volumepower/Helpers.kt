package com.example.volumepower

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.PowerManager

object TorchHelper {
    private var id: String? = null
    private var on = false
    private var inited = false

    private fun init(ctx: Context) {
        if (inited) return
        inited = true
        val cm = ctx.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        id = cm.cameraIdList.firstOrNull {
            val c = cm.getCameraCharacteristics(it)
            c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
        }
        cm.registerTorchCallback(object : CameraManager.TorchCallback() {
            override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
                if (cameraId == id) on = enabled
            }
        }, null)
    }

    fun toggle(ctx: Context) {
        try {
            init(ctx)
            val cm = ctx.applicationContext.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val i = id ?: return
            cm.setTorchMode(i, !on)
        } catch (_: Exception) {
        }
    }
}

object ScreenHelper {
    @Suppress("DEPRECATION")
    fun wake(ctx: Context) {
        val pm = ctx.applicationContext.getSystemService(Context.POWER_SERVICE) as PowerManager
        val wl = pm.newWakeLock(
            PowerManager.FULL_WAKE_LOCK or
                PowerManager.ACQUIRE_CAUSES_WAKEUP or
                PowerManager.ON_AFTER_RELEASE,
            "VolumePower:wake"
        )
        wl.acquire(3000)
    }
}


object EventLog {
    private val items = ArrayDeque<String>()
    private val fmt = java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US)

    @Synchronized
    fun add(msg: String) {
        items.addFirst(fmt.format(java.util.Date()) + "  " + msg)
        while (items.size > 40) items.removeLast()
    }

    @Synchronized
    fun dump(): String = if (items.isEmpty()) "(কোনো ইভেন্ট আসেনি)" else items.joinToString("\n")
}
