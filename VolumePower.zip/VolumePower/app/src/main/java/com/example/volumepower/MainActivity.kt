package com.example.volumepower

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "Volume Power"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
            text = """
ব্যবহারের নিয়ম:

🔊 ভলিউম আপ (১ বার চাপ) → স্ক্রীন অন / অফ

🔉 ভলিউম ডাউন (চেপে ধরে রাখুন) → পাওয়ার মেনু

🔉 ভলিউম ডাউন (২ বার চাপ) → ফ্ল্যাশলাইট অন / অফ

🔉 ভলিউম ডাউন (১ বার চাপ) → ভলিউম কমবে

🎵 স্ক্রীন অন থাকা অবস্থায় গান/ভিডিও চললে বাটনগুলো স্বাভাবিক ভলিউমের মতোই কাজ করবে।

শুরু করতে নিচের বাটনে চেপে Accessibility সেটিংসে "Volume Power" চালু করুন।
""".trimIndent()
        })
        root.addView(Button(this).apply {
            text = "Accessibility সেটিংস খুলুন"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        })
        setContentView(root)
    }
}
