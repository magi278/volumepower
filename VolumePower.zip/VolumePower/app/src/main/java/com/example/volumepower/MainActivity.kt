package com.example.volumepower

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    private fun refresh() {
        status.text = "Accessibility: " + (if (VolumeKeyService.instance != null) "চালু ✅" else "বন্ধ ❌") +
            "\nKeyService: " + (if (KeyService.running) "চালু ✅" else "বন্ধ ❌") +
            "\n\nইভেন্ট লগ:\n" + EventLog.dump()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        try {
            startForegroundService(Intent(this, KeyService::class.java))
        } catch (_: Exception) {
        }

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        root.addView(TextView(this).apply {
            text = "Volume Power"
            textSize = 26f
            setTypeface(null, Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, pad)
            text = """
ব্যবহারের নিয়ম:

🔊 ভলিউম আপ (১ বার চাপ) → স্ক্রীন অন / অফ

🔉 ভলিউম ডাউন (চেপে ধরে রাখুন) → পাওয়ার মেনু

🔉 ভলিউম ডাউন (২ বার চাপ) → ফ্ল্যাশলাইট অন / অফ

🎵 স্ক্রীন অন থাকা অবস্থায় গান/ভিডিও চললে বাটনগুলো স্বাভাবিক ভলিউমের মতো কাজ করবে।

সেটআপ (দুটোই করতে হবে):
১) নিচের প্রথম বাটন চেপে Accessibility-তে "Volume Power" চালু করুন।
২) দ্বিতীয় বাটন চেপে ব্যাটারি সেটিংসে Volume Power কে "Unrestricted / No restrictions" করুন।
৩) নোটিফিকেশনের অনুমতি দিন। "Volume Power চালু আছে" নোটিফিকেশনটা মুছবেন না।
""".trimIndent()
        })
        root.addView(Button(this).apply {
            text = "১) Accessibility সেটিংস"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "২) ব্যাটারি সেটিংস"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })
        root.addView(Button(this).apply {
            text = "৩) লগ রিফ্রেশ"
            setOnClickListener { refresh() }
        })
        status = TextView(this).apply { textSize = 13f; setPadding(0, pad, 0, 0) }
        root.addView(status)
        refresh()
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
